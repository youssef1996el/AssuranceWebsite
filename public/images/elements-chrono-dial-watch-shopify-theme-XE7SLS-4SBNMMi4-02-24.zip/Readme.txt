Within the main folder [Chrono-Dial-V1] there will be following folder and files.


Documentation
Readme.txt
log.txt
Install.zip 


------------------------------------------------------------------------------------------------------------------------------------

http://themessupport.com/documentation/doc/chrono/

Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.
DesignThemes.
 









